package hellowold;

public class helloworld {
	
	public static void main(String args[]) {
		System.out.print("The sum of these no is: ");
		int num1 = 4;
		int num2 = 6;
		int num3 = 8;
		int sum = num1+ num2 + num3;
		System.out.println(sum);
		
	}
	

}
