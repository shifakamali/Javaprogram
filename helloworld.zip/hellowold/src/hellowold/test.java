package hellowold;

public class test {
	public static void main(String args[]) {
		byte age = 34;
		int age2 = 56;
		short age3 = 87;
		long ageDino = 5666666666l;
		char ch = 'A';
		float f1 = 5.6F;
		double d = 4.66d;
		boolean a = true;
		System.out.println(age);
		System.out.println(ch);
		System.out.println(f1);
		System.out.println(d);
		System.out.println(age2);
		System.out.println(age3);
		System.out.println(ageDino);
		System.out.println(a);
		String str = "harry";
		System.out.println(str);
	}

}
